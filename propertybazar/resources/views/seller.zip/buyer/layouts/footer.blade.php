<!-- jQuery -->
<script src="https://textcode.co.in/propertybazar/public/assets/js/jquery.min.js"></script>
<script src="https://textcode.co.in/propertybazar/public/assets/js/popper.min.js"></script>
<script src="https://textcode.co.in/propertybazar/public/assets/js/bootstrap.min.js"></script>
<!-- wow animation -->
<script src="https://textcode.co.in/propertybazar/public/assets/js/animate.js"></script>
<!-- select country -->
<script src="https://textcode.co.in/propertybazar/public/assets/js/bootstrap-select.js"></script>
<!-- owl carousel -->
<script src="https://textcode.co.in/propertybazar/public/assets/js/owl.carousel.js"></script>
<!-- chart js -->
<script src="https://textcode.co.in/propertybazar/public/assets/js/Chart.min.js"></script>
<script src=https://textcode.co.in/propertybazar/public/assets/js/Chart.bundle.min.js"></script>
<script src="https://textcode.co.in/propertybazar/public/assets/js/utils.js"></script>
<script src="https://textcode.co.in/propertybazar/public/assets/js/analyser.js"></script>

<!-- nice scrollbar -->
<script src="https://textcode.co.in/propertybazar/public/assets/js/perfect-scrollbar.min.js"></script>
<script>
    var ps = new PerfectScrollbar('#sidebar');
</script>
<!-- custom js -->
<script src="https://textcode.co.in/propertybazar/public/assets/js/custom.js"></script>
<script src="https://textcode.co.in/propertybazar/public/assets/js/chart_custom_style1.js"></script>
</body>

</html>
